$(document).ready(
        function() {

          $.each(data.Products, function(index, item) {

            if (index <= 5) {

              if (index != 0) {
                $("#productdetail").clone(true).insertAfter(
                        "#productdetail" + (index - 1)).attr("id",
                        "productdetail" + index).removeClass("hide");
              } else {
                $("#productdetail").clone(true).insertAfter("#productdetail")
                        .attr("id", "productdetail" + index)
                        .removeClass("hide");

              }

              filltopdetails(index, item);
            }

          });

          $.each(data.Products,
                  function(index, item) {


                    $('#datatable tr:last').after(
                            $("#productsaletablerow").clone(true).attr("id",
                                    "productsaletablerow" + index).removeClass(
                                    "hide"));

         
                    fillproducttable(index, item);

                  });

          $("#productsaletablerow").remove();

          var table = $('#datatable').DataTable({

          });

          table.on('search.dt', function() {

            $(".more").removeClass("more");
            $('#datatable').find($(".fa-arrow-circle-up")).removeClass(
                    "fa-arrow-circle-up").addClass("fa-arrow-circle-down");

          });

        });

function filltopdetails(index, item) {

  var con = $("#productdetail" + index);
  con.find(".product_name").text(item.name);
  con.find(".count").text(totalsales(item.Versions));

}

function fillproducttable(index, item) {

  var con = $("#productsaletablerow" + index);
  con.find(".productname").text(item.name);
  con.find(".faicon").removeClass("hide");

  con.find(".releasedate").text(item.Versions[0].date);
  con.find(".version").text(item.Versions[0].Version);
  con.find(".sales").text(totalsales(item.Versions));
  con.find(".addproduct").removeClass("hide");

  addchildversions(index, item);
}

function addchildversions(index, item) {

  $.each(item.Versions, function(index1, item1) {

    $('#versiontable').append(
            $("#productsaletablerow").clone(true).attr("id",
                    "productdetail" + index + index1).addClass(
                    "productdetail" + index).addClass("template"));

    var con = $("#productdetail" + index + index1);

    con.find(".releasedate").text(item1.date);
    con.find(".version").text(item1.Version);
    con.find(".sales").text(item1.sales);

    con.find(".deleteproduct").removeClass("hide");
    con.find(".editproduct").removeClass("hide");

  });

}

function totalsales(item) {

  var totalsales = 0;
  $.each(item, function(index, item) {

    totalsales += item.sales;

  });

  return totalsales;
}

$(".addproduct").click(function() {

  selectedproduct = $(this).closest('tr').prop('id');
  mode = 1;
  $("#noofsalesinput").val('');
  $("#releasedateinput").val('');
  $("#versioninput").val('');

  $('#addform').modal({
    backdrop: 'static',
    keyboard: true
  })

});

$(".deleteproduct").click(function() {
  var element = $(this).closest('tr')
  bootbox.confirm("Are you sure you want to delete product?", function(result) {

    if (result) {
      element.addClass("hide");
    }
  });

});

var selectedproduct;
var mode;

$(".editproduct").click(function() {

  selectedproduct = $(this).closest('tr').prop('id');
  mode = 0;
  var con = $(this).closest('tr');

  $("#noofsalesinput").val(con.find(".sales").text());
  $("#releasedateinput").val(con.find(".releasedate").text());
  $("#versioninput").val(con.find(".version").text());
  $('#addform').modal({
    backdrop: 'static',
    keyboard: true
  })

});

$(".saveproduct").click(
        function() {

          var noofsales = $("#noofsalesinput").val();
          var releasedate = $("#releasedateinput").val();
          var version = $("#versioninput").val();

          var con = $("#" + selectedproduct);

          if (noofsales == "" || releasedate == "" || version == "") {

            bootbox.alert("Please enter all fields");

            return false;
          }

          if (mode == 0) {

          }

          else {

            var rowCount = $('#datatable tr').length;
            var index = selectedproduct.replace("productsaletablerow", "");

            $("#templatefile").clone(true).insertAfter("#" + selectedproduct)
                    .attr("id", "productsaletablerow" + (rowCount + 1))
                    .removeClass("hide").addClass("productdetail" + index)
                    .addClass("newelement");

            con = $("#productsaletablerow" + (rowCount + 1));
            con.find(".deleteproduct").removeClass("hide");
            con.find(".editproduct").removeClass("hide");

          }

          con.find(".releasedate").text(releasedate);
          con.find(".version").text(version);
          con.find(".sales").text(noofsales);

          $('#addform').modal('hide');

        });

$(".faicon").click(
        function() {

          var id = $(this).closest('tr').prop('id').replace(
                  "productsaletablerow", "");

          console.log(!$(this).hasClass('more'));

          if (!$(this).hasClass('more')) {

            $(this).addClass('more');
      
            console.log("#productsaletablerow" + id);

            $( ".productdetail" + id).removeClass('hide');
            
            $("#versiontable .productdetail" + id).each(function(i, obj) {

              $(this).removeClass('hide');
              $(this).clone(true).insertAfter("#productsaletablerow" + id);

            });

            $(this).find($(".fa")).removeClass("fa-arrow-circle-down")
                    .addClass("fa-arrow-circle-up");
          }

          else {
            $(this).removeClass('more');

            $(".productdetail" + id).addClass("hide");
            $(this).find($(".fa")).removeClass("fa-arrow-circle-up").addClass(
                    "fa-arrow-circle-down");

            $("#datatable .productdetail" + id).each(function(i, obj) {

              console.log("HAs"+$(this).hasClass('newelement'));
              
              if (!$(this).hasClass('newelement')) {
                $(this).remove();
              }

            });

          }

        });