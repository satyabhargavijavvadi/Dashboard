var labels = [];
var chartdata = [];
var chartdatabar = [];

$.each(data.Products, function(index, item) {

  var customobject = new Object();

  var sales = totalsales(item.Versions);

  labels.push(item.name);

  customobject.name = item.name;
  customobject.value = sales;

  chartdata.push(customobject);

  chartdatabar.push(sales);

});

google.charts.load("current", {
  packages: ["corechart"]
});
google.charts.setOnLoadCallback(drawChart);
function drawChart() {
  var datacharts = new google.visualization.DataTable();
  
  datacharts.addColumn('string', 'Project');
  datacharts.addColumn('number', 'Sales');
  
  $.each(data.Products, function(index, item) {

    var customobject = new Object();

    var sales = totalsales(item.Versions);

    datacharts.addRow([item.name, sales]);

  });
  

  var options = {
    title: '',
    legend: { position: 'right' }

  };

  var chart = new google.visualization.PieChart(document
          .getElementById('piechart_3d'));
  chart.draw(datacharts, options);
}

$(window).resize(function(){
  drawChart();
});